#!/usr/bin/python

##################################
# module: image_crop.py
# author: vladimir kulyukin
# description: crop ROI specified
# by user command parameters
##################################

import argparse
import cv2

ap = argparse.ArgumentParser()
ap.add_argument('-ip', '--image_path', required=True, help='path to image')
ap.add_argument('-sr', '--start_row', required=True, help='start row')
ap.add_argument('-er', '--end_row', required=True, help='end row')
ap.add_argument('-sc', '--start_col', required=True, help='start col')
ap.add_argument('-ec', '--end_col', required=True, help='end col')
args = vars(ap.parse_args())

image = cv2.imread(args['image_path'])
sr, er = int(args['start_row']), int(args['end_row'])
sc, ec = int(args['start_col']), int(args['end_col'])

cropped_region = image[sr:er, sc:ec]

cv2.imshow('Image', image)
cv2.imshow('Cropped Region', cropped_region)
cv2.waitKey(0)
del image
del cropped_region


