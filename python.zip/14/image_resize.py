#!/usr/bin/python

##################################
# module: image_resize.py
# author: vladimir kulyukin
# description: resize an image
##################################

import argparse
import cv2

ap = argparse.ArgumentParser()
ap.add_argument('-ip', '--img_path', required=True, help='path to image')
ap.add_argument('-w', '--width', required=True, help='new width')
args = vars(ap.parse_args())

image = cv2.imread(args['img_path'])
(h, w, num_channels) = image.shape
print 'h=' + str(h) + '; ' + 'w=' + str(w) + '; ' + 'c=' + str(num_channels)

new_width   = int(args['width'])
width_ratio = float(new_width) / w
print width_ratio

dim = (new_width, int(h * width_ratio))
resized_image = cv2.resize(image, dim, interpolation=cv2.INTER_AREA)
(nh, nw, nnum_channels) = resized_image.shape
print 'nh=' + str(nh) + '; ' + 'nw=' + str(nw) + '; ' + 'nc=' + str(nnum_channels)

cv2.imshow('Image', image)
cv2.imshow('Resized Image', resized_image)
cv2.waitKey(0)

