#!/usr/bin/python

import cv2
import numpy as np

image = np.zeros((512, 512, 3), np.uint8)
cv2.line(image, (0, 0), (511, 511), (255, 127, 0), 2)
cv2.imshow('Blue line', image)
del image

image2 = np.zeros((512, 512, 3), np.uint8)
cv2.rectangle(image2, (100, 100), (300, 250), (127, 50, 127), 2)
cv2.imshow('Rectangle', image2)
del image2

image3 = np.zeros((512, 512, 3), np.uint8)
cv2.circle(image3, (300, 200), 100, (15, 75, 50), -1)
cv2.imshow('Circle', image3)
del image3

cv2.waitKey(0)
cv2.destroyAllWindows()















