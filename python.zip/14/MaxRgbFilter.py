import numpy as np
import argparse
import cv2

def max_rgb_filter(image):
    (B, G, R) = cv2.split(image)
    M = np.maximum(np.maximum(R, G), B)
    R[R < M] = 0
    G[G < M] = 0
    B[B < M] = 0
    return cv2.merge([B, G, R])

ap = argparse.ArgumentParser()
ap.add_argument('-ip', '--img_path', required=True, help='path to input image')
args = vars(ap.parse_args())

image = cv2.imread(args['img_path'])
shifted = cv2.pyrMeanShiftFiltering(image, 21, 51)
filtered = max_rgb_filter(image)
cv2.imshow('Horizontal stack: RGB Filtered (Left); Original Image (Right)', np.hstack([filtered, image]))
cv2.imshow('Vertical Stack: RGB Filtered2 (up); Original Image (down)', np.vstack([filtered, image]))
cv2.waitKey(0)

