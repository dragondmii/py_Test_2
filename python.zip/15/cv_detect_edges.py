import argparse
import cv2

#######################################
# module: blurring.py
# author: vladimir kulyukin
# description: use canny edge detection	
# To run: python cv_detect_edges -i <image_path>
#######################################

ap = argparse.ArgumentParser()
ap.add_argument('-i', '--image', required=True,
                help='path to input image')
args    = vars(ap.parse_args())
image   = cv2.imread(args['image'])
ih, iw  = image.shape[:2]

gray_image  = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
image_edges = cv2.Canny(gray_image, 100, 200, apertureSize=3, L2gradient=True)

cv2.imshow('Input', image)
cv2.imshow('Gray Image', gray_image)
cv2.imshow('Edges', image_edges)

cv2.waitKey(0)

del image
del gray_image
del image_edges

