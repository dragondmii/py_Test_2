#!/usr/bin/python

class fiboiter(object):
  fibprev = 0
  fibcurr = 1
  def __init__(self, count):
    self.count = count
    fiboiter.fibprev = 0
    fiboiter.fibcurr = 1

  def __iter__(self):
    return self

  def next(self):
    if self.count < 0:
      raise StopIteration
    self.count -= 1
    r = fiboiter.fibprev
    fib = fiboiter.fibprev + fiboiter.fibcurr
    fiboiter.fibprev = fiboiter.fibcurr
    fiboiter.fibcurr = fib
    return r

  __next__ = next # this is for Py3 compatibility

def test_01():
  for fib in fiboiter(7): print(fib)


def test_02():
  for n, fib in zip(xrange(8), fiboiter(7)):
    print('%d -> %fib' % (n, fib))








