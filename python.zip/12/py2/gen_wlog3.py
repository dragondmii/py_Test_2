#!/usr/bin/python

import re
import sys
import os
import fnmatch

## to run: python gen_wlog3.py nasa_wlog_data/

def find_files(filepat, rootdir):
  for path, dirlist, filelist in os.walk(rootdir):
    for file_name in fnmatch.filter(filelist, filepat):
      yield os.path.join(path, file_name)

def open_files(filenames):
  for fn in filenames:
    if fn.endswith('.txt'):
      yield open(fn)

def get_lines(filestreams):
  for fs in filestreams:
    for line in fs:
      yield line

def grep_lines(pat, group_num, lines):
  cpat = re.compile(pat)
  for line in lines:
    m = re.match(cpat, line)
    if m != None:
      yield m.group(group_num)

logpat = r'^([\d\.\w-]+)\s+(- -)\s+\[(\d{2}\/\w{3}\/\d{4}):(\d{2}:\d{2}:\d{2}).+\]\s+\"(.+)\s+(.+)\s+(.+)\"\s+(\d+)\s+(\d+)$'
logs = find_files(r'access_*', sys.argv[1])
streams = open_files(logs)
lines = get_lines(streams)
grep_lines = grep_lines(logpat, 9, lines)
print 'Total transferred bytes = ', sum(int(i) for i in grep_lines)


















