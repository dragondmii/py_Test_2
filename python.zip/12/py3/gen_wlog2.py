#!/usr/bin/python3

import re
import sys
logpat = r'^([\d\.\w-]+)\s+(- -)\s+\[(\d{2}\/\w{3}\/\d{4}):(\d{2}:\d{2}:\d{2}).+\]\s+\"(.+)\s+(.+)\s+(.+)\"\s+(\d+)\s+(\d+)$'

def sum_tran_bytes(pat, log, group_num): 
  matches   = (re.match(pat, line) for line in open(log))
  tranbytes = (int(match.group(group_num)) for match in matches if match != None)
  return sum(tranbytes)

if __name__ == '__main__':
  print('Total transferred bytes = %d' % sum_tran_bytes(logpat, sys.argv[1], 9))











